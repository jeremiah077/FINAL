const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// Set canvas size
canvas.width = 400;
canvas.height = 400;

// Pac-Man properties
let pacman = {
    x: 50,
    y: 50,
    size: 20,
    speed: 5,
    dx: 5,
    dy: 0
};

// Control Pac-Man movement
function movePacman() {
    pacman.x += pacman.dx;
    pacman.y += pacman.dy;

    // Wall collision
    if (pacman.x + pacman.size > canvas.width) pacman.x = 0;
    if (pacman.x < 0) pacman.x = canvas.width - pacman.size;
    if (pacman.y + pacman.size > canvas.height) pacman.y = 0;
    if (pacman.y < 0) pacman.y = canvas.height - pacman.size;
}

// Draw Pac-Man
function drawPacman() {
    ctx.beginPath();
    ctx.arc(pacman.x, pacman.y, pacman.size, 0.2 * Math.PI, 1.8 * Math.PI); // Open mouth
    ctx.lineTo(pacman.x, pacman.y); // Draw to center
    ctx.fillStyle = "yellow";
    ctx.fill();
    ctx.closePath();
}

// Clear the canvas
function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

// Update game
function update() {
    clearCanvas();
    drawPacman();
    movePacman();
    requestAnimationFrame(update);
}

// Keyboard event listeners
function changeDirection(e) {
    if (e.key === "ArrowRight") {
        pacman.dx = pacman.speed;
        pacman.dy = 0;
    } else if (e.key === "ArrowLeft") {
        pacman.dx = -pacman.speed;
        pacman.dy = 0;
    } else if (e.key === "ArrowUp") {
        pacman.dx = 0;
        pacman.dy = -pacman.speed;
    } else if (e.key === "ArrowDown") {
        pacman.dx = 0;
        pacman.dy = pacman.speed;
    }
}

// Event listener for key presses
document.addEventListener("keydown", changeDirection);

// Start the game
update();
