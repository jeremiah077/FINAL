const monthYear = document.getElementById("monthYear");
const calendarDays = document.getElementById("calendarDays");
const prevButton = document.getElementById("prev");
const nextButton = document.getElementById("next");

let date = new Date();

function renderCalendar() {
    date.setDate(1);
    const currentMonth = date.getMonth();
    const currentYear = date.getFullYear();
    const firstDayIndex = date.getDay();
    const lastDay = new Date(currentYear, currentMonth + 1, 0).getDate();
    const prevLastDay = new Date(currentYear, currentMonth, 0).getDate();

    monthYear.innerText = `${date.toLocaleString("default", { month: "long" })} ${currentYear}`;
    calendarDays.innerHTML = "";

    // Previous month's days
    for (let i = firstDayIndex; i > 0; i--) {
        const day = document.createElement("span");
        day.classList.add("inactive");
        day.innerText = prevLastDay - i + 1;
        calendarDays.appendChild(day);
    }

    // Current month's days
    for (let i = 1; i <= lastDay; i++) {
        const day = document.createElement("span");
        day.innerText = i;
        if (i === new Date().getDate() && currentMonth === new Date().getMonth() && currentYear === new Date().getFullYear()) {
            day.classList.add("active");
            day.style.backgroundColor = "#007bff";
            day.style.color = "#fff";
            day.style.borderRadius = "50%";
        }
        calendarDays.appendChild(day);
    }

    // Next month's days
    const nextDays = 7 - (calendarDays.children.length % 7);
    for (let i = 1; i <= nextDays; i++) {
        const day = document.createElement("span");
        day.classList.add("inactive");
        day.innerText = i;
        calendarDays.appendChild(day);
    }
}

// Navigate between months
prevButton.addEventListener("click", () => {
    date.setMonth(date.getMonth() - 1);
    renderCalendar();
});

nextButton.addEventListener("click", () => {
    date.setMonth(date.getMonth() + 1);
    renderCalendar();
});

renderCalendar();
